const { web3 , myAccount } = require("./utils")
const { globalhub_abi , localhub_abi} = require("./artifacts")

let globalhub = new web3.eth.Contract( JSON.parse(globalhub_abi) , "0xC00e8e47214324c945Af98EbCf710B20D6f89653" )

async function run()
{
    let NE_Addr = await globalhub.methods.getLocalHubAddr( +1 , +1 ).call()

    let NE_Hub = new web3.eth.Contract( JSON.parse(localhub_abi) , NE_Addr )

    for( i = 0 ; i < 10 ; i++ )
    {
    await NE_Hub.methods.addRequest( "" ).send(
        {
            from:myAccount.address,
            gas:800000
        }
    )
    }

    let record = await NE_Hub.methods.getRequests().call()

    console.log(record)
}

run()