const Web3 = require("Web3")

const web3 = new Web3("http://192.168.43.61:8545")

const privateKey = "0xef0c182c519c817b5ee4ac9f01ab9d70d94a0aa318692ec20593655e75c69916"
const myAccount = web3.eth.accounts.wallet.add(privateKey)

module.exports={
    web3:web3,
    myAccount:myAccount
}