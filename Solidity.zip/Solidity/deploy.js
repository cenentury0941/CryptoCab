const { web3 , myAccount } = require('./utils.js')
const { globalhub_bytecode , localhub_bytecode , localhub_abi , globalhub_abi } = require( './artifacts.js' )

async function deploy()
{

    let globalhub_receipt = await web3.eth.sendTransaction(
        {
            from:myAccount.address,
            gas:800000,
            data:globalhub_bytecode
        }
    ).on("receipt" , console.log)

    let nw_receipt = await web3.eth.sendTransaction(
        {
            from:myAccount.address,
            gas:800000,
            data:localhub_bytecode
        }
    ).on("receipt" , console.log)

    let ne_receipt = await web3.eth.sendTransaction(
        {
            from:myAccount.address,
            gas:800000,
            data:localhub_bytecode
        }
    ).on("receipt" , console.log)

    let se_receipt = await web3.eth.sendTransaction(
        {
            from:myAccount.address,
            gas:800000,
            data:localhub_bytecode
        }
    ).on("receipt" , console.log)

    let sw_receipt = await web3.eth.sendTransaction(
        {
            from:myAccount.address,
            gas:800000,
            data:localhub_bytecode
        }
    ).on("receipt" , console.log)

    let global_addr = globalhub_receipt.contractAddress
    let nw_addr = nw_receipt.contractAddress
    let ne_addr = ne_receipt.contractAddress
    let se_addr = se_receipt.contractAddress
    let sw_addr = sw_receipt.contractAddress

    console.log( "NW : " + nw_addr )
    console.log( "NE : " + ne_addr )
    console.log( "SE : " + se_addr )
    console.log( "SW : " + sw_addr )

    let GlobalHub = new web3.eth.Contract( JSON.parse(globalhub_abi) , global_addr )

    let nw_log = await GlobalHub.methods.setLocalHubAddr( +1 , -1 , nw_addr ).send(
        {
            from:myAccount.address,
            gas:800000
        }
    )

    let ne_log = await GlobalHub.methods.setLocalHubAddr( +1 , +1 , ne_addr ).send(
        {
            from:myAccount.address,
            gas:800000
        }
    )

    let se_log = await GlobalHub.methods.setLocalHubAddr( -1 , +1 , se_addr ).send(
        {
            from:myAccount.address,
            gas:800000
        }
    )

    let sw_log = await GlobalHub.methods.setLocalHubAddr( -1 , -1 , sw_addr ).send(
        {
            from:myAccount.address,
            gas:800000
        }
    )

    nw_addr = await GlobalHub.methods.getLocalHubAddr(+1,-1).call()
    ne_addr = await GlobalHub.methods.getLocalHubAddr(+1,+1).call()
    se_addr = await GlobalHub.methods.getLocalHubAddr(-1,+1).call()
    sw_addr = await GlobalHub.methods.getLocalHubAddr(-1,-1).call()

    console.log(" ");
    console.log( "NW : " + nw_addr )
    console.log( "NE : " + ne_addr )
    console.log( "SE : " + se_addr )
    console.log( "SW : " + sw_addr )
    
    console.log(" ");
    console.log( "Global Address : " + global_addr );
    console.log(" ");


    let LocalHubNW = new web3.eth.Contract( JSON.parse(localhub_abi) , nw_addr )
    let nw_requests = await LocalHubNW.methods.getRequests().call()

    console.log( "NW_REQ : " + nw_requests )

}


deploy()